// Require & Import Variables

var express = require('express'),
	mongoose = require('mongoose'),
	app = express(),
	bodyParser = require('body-parser'),
	Comment = require("./models/comment"),
	User = require("./models/user"),
	seedDB = require("./seeds")


// connect mongoose database
	
mongoose.connect('mongodb://localhost/bs', { useNewUrlParser: true });
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view engine', 'ejs');
seedDB();




//home page

app.get("/", function(req, res){
    res.render("index");
});




//chatbox
// show all comments initially before creating then showing users and their comments

app.get("/chatbox", function(req, res) {
	// get users
	
	User.find({}, function(err, allUsers) {
		if (err) {
			console.log(err);
		} else {
			res.render("chatbox", {user: allUsers});
			console.log(allUsers);
		}
	});
});


// v1 of populate command to show all comments
app.get("/chatbox", function(req, res){
	User.find({_id}).populate("comments").exec(function(err, user) {
	if (err) {
		console.log(err);
	} else {
		console.log(user);
	}
		    res.render("chatbox", {user: user});

	})
});










// Server connection to port 


app.listen(3000, process.env.IP, function(){
   console.log("The YelpCamp Server Has Started!");
});