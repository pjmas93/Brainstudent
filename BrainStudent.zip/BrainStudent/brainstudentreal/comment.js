// THE MODEL USED FOR COMMENTING FOR USERS
var mongoose = require('mongoose');
var User = require('./user.js');


//THE LOGIC BEHIND DEFINING A COMMENT UNDER MONGOOSE SCHEMA

var commentSchema = mongoose.Schema ({
	comments: String
});

// var Comment = mongoose.model("Comment", commentSchema);

module.exports =  mongoose.model("Comment", commentSchema);

// Could do it like this but it didnt get defined before
// var User = mongoose.model("User", userSchema);