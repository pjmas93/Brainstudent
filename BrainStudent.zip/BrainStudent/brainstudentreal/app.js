// REQUIRE ALL OF THE FILES INSTALLED ON DEPENDENCIES

var express = require('express');
var app = express();	
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var passport = require('passport');
var LocalStrategy = require('passport-local');
var Comment = require('./comment.js');
var User = require('./user.js');
// var EmbedCommentUser = require('./embed');
var CSSapp = require('./public/stylesheets/app.css');
// const ejsLint = require('ejs-lint'); 


	
mongoose.connect('mongodb://localhost/brainstudent', { useNewUrlParser: true });
// app.set('views', './brainstudentreal/views');
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(__dirname + '/public'));

// Require all of the other files of EJS for home, signup, etc. pages

// var Home = require("/home");

// Create a database of users!

// var userSchema = new mongoose.Schema({
// 	name: String,
// 	email: String,
// 	city: String,
// 	careertype: String,
// 	comment: [commentSchema]

// });

// var User = mongoose.model("User", userSchema);

User.create({
	name: "Paul Je",
	email: "pjeewoo@gmail.com",
	city: "Toronto",
	careertype: "Marketing"
}, function(err, user) {
	if(err) {
	console.log(err);
} 	else {
	console.log(user); 
}
	user.save();
});

// Redirections for each of the routes that users can click on

app.get("/", function(req, res) {
	res.render("index.ejs");
})



app.get("/chatbox", function(req, res) {
	// find all the users and their respective comments
	User.findById(User.id).populate("comments").exec(function(err, user) {
		if (err) {
			console.log(err);
			res.redirect("/chatbox");
		} else {
			// render the chatbox with the users' information
			res.render("comment", {user: User});
		}
	})
	// res.render("chatbox", {User: "User"});
})

app.post("/chatbox/newmessage", function(req, res) {
	User.findById(req.params.id, function(err, user) {
		if (err) {
			console.log(err);
			res.redirect("/chatbox");
		} else {
			Comment.create(req.body.comment, function(err, comment) {
				if (err) {
					console.log(err);
				} else {
					user.comments.push(comment);
					comment.save;
					res.redirect("/chatbox");
				}
			}
		)}
	})
})
		




app.get("/signup", function(req,res) {
	res.render("signup");
})

app.get("/login", function(req,res) {
	res.render("login");
})





	
	/// Needed connections to connect with the plugins installed after requiring


	app.listen(3000	, function() {
	console.log("The server has started!!");
})