// we're going to embed the code of the user and comments they make 

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/brainstudent');

// define comment in variable before userSchema

//REQUIRED FROM MODELS FILE COMMENT.JS
// var Comment = require('./comment.js');

var commentSchema = new mongoose.Schema ({
	comment: String
});

var Comment = mongoose.model("Comment", commentSchema);

module.exports =  Comment;

//REQUIRED FROM MODELS FILE USER.JS

// var User = require('./user');

// THE MODEL USED FOR COMMENTING FOR USERS respective of each USER
// var Comment = require('comment');

var userSchema = new mongoose.Schema({
	name: String,
	email: String,
	city: String,
	careertype: String,
	comment: [commentSchema]
});

var User = mongoose.model("User", userSchema);
module.exports = User;



var newUser = new User ({
	name: String,
	email: String,
	city: String,
	careertype: String,
	comment: [commentSchema]
});

newUser.comment.push({
	comment: String
})

newUser.save(function(err, user) {
	if (err) {
		console.log(err);
	} else {
		console.log(user);
	}
});

// User.findOne({name: "Paul Je"}, function(err,user) {
// 	if(err) {
// 		console.log(err);
// 	} else {
// 		user.comment.push({
// 			comment: "My pushed comment into the array of things and history of what I said on this platform!"
// 		});
// 		user.save(function(err,user) {
// 	if (err) {
// 		console.log(err);
// 	} else {
// 		console.log(user);
// 	}
// 		})
// 	} 
// });


// var newComment = new Comment ({
// 	comment: "What's up Brainstudents??"
// });

// newComment.save(function(err, comment) {
// 	if (err) {
// 		console.log(err);
// 	} else {
// 		console.log(comment);
// 	}
// });
