// THE MODEL USED FOR COMMENTING FOR USERS respective of each USER
var mongoose = require('mongoose');
var Comment = require('./comment');

var userSchema = new mongoose.Schema({
	name: String,
	email: String,
	city: String,
	careertype: String,
	comments: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: "Comment"
		}
		
	]
});

var User = mongoose.model("User", userSchema);
module.exports = User;

// Could do it like this but it didnt get defined before
// var User = mongoose.model("User", userSchema);
